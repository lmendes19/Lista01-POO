﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Quadrado quadrado1;
            quadrado1 = new Quadrado();

            Console.WriteLine("Digite o valor da Diagonal: ");
            quadrado1.setD1(double.Parse(Console.ReadLine()));
            
            quadrado1.operacaolado();
            quadrado1.operacao();
            

            Console.WriteLine("Resultado: {0}", quadrado1.getResultado());

        }
    }
}
