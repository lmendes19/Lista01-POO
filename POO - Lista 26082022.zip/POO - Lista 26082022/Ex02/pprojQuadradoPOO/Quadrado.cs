﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pprojQuadradoPOO
{
    internal class Quadrado
    {
        private double a1;
        private double a2;
        private double resultado;

        public void setA1(double a)
        {
            a1 = a;
        }
        public void setA2(double a)
        {
            a2 = a;
        }
        public double getA1()
        {
            return a1;
        }
        public double getA2()
        {
            return a2;
        }
        public double getResultado()
        {
            return resultado;
        }
        public void Multiplicar()
        {
            resultado = a1 * a2;
        }



    }
}
