﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Triangulo triangulo1;
            triangulo1 = new Triangulo();

            Console.WriteLine("Calcule a area de um triangulo a partir deste software");
            Console.WriteLine("Entre com o valor da base");
            triangulo1.setB2(double.Parse(Console.ReadLine()));
            Console.WriteLine("Entre com o valor da altura");
            triangulo1.setA1(double.Parse(Console.ReadLine()));

            triangulo1.operacao();

            Console.WriteLine("Valor da area: {0}",triangulo1.getResultado());


        }
    }
}
