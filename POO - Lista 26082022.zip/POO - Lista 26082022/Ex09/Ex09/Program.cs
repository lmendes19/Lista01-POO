﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Comparacao02 comparacao02;
            comparacao02 = new Comparacao02();

            Console.WriteLine("Digite dois valores e obtenha o maior na sua tela");
            Console.WriteLine("Digite o primeiro valor");
            comparacao02.setV1(double.Parse(Console.ReadLine()));
            Console.WriteLine("Digite o segundo valor");
            comparacao02.setV2(double.Parse(Console.ReadLine()));

            comparacao02.compara();
            comparacao02.compara1();
            comparacao02.Erro();

            
            
            Console.WriteLine("Maior valor: {0}", comparacao02.getM());


        }
    }
}
