﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex08
{
    internal class Comparacao
    {

        private double v1;
        private double v2;
        private double m;
        
        public void setV1(double v)
        {
            v1 = v;
        }
        public void setV2(double v)
        {
            v2 = v;
        }
        public double getV1()
        {
            return v1;
        }
        public double getV2()
        {
            return v2;
        }
        public void comp1()
        {
           if (v1 > v2)
            {
                m = v1;
            }
        }
        public void comp2()
        {
            if (v2 > v1)
            {
                m = v2;
            }
        }
        public double getM()
        {
            return m;
        }
       

    }
}
